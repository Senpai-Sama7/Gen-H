
-- HVAC Template Library Database Schema

-- Templates Table
CREATE TABLE templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    slug VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    framework VARCHAR(100), -- 'technical-elegance', 'trust-reliability', 'performance-showcase', 'modern-minimalist'
    status VARCHAR(50), -- 'active', 'archived', 'draft'
    version VARCHAR(50),

    -- Design System
    primary_color VARCHAR(7),
    secondary_color VARCHAR(7),
    accent_color VARCHAR(7),
    typography_headline VARCHAR(100),
    typography_body VARCHAR(100),

    -- Features
    has_3d_viewer BOOLEAN DEFAULT false,
    has_calculator BOOLEAN DEFAULT false,
    has_before_after BOOLEAN DEFAULT false,
    has_testimonials BOOLEAN DEFAULT false,
    has_case_studies BOOLEAN DEFAULT false,
    has_service_map BOOLEAN DEFAULT false,

    -- Frontend
    frontend_repo_url VARCHAR(500),
    frontend_branch VARCHAR(100),

    -- Backend
    backend_repo_url VARCHAR(500),
    backend_branch VARCHAR(100),

    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES users(id),
    preview_image_url VARCHAR(500),
    preview_video_url VARCHAR(500),
    documentation_url VARCHAR(500),

    -- Configuration
    config JSONB DEFAULT '{}',
    customizable_sections JSONB DEFAULT '[]'
);

-- Companies Table
CREATE TABLE companies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20),
    website_url VARCHAR(500),

    -- Service Info
    service_areas JSONB, -- [{city, state, zip}, ...]
    business_type VARCHAR(100), -- 'residential', 'commercial', 'both'
    years_in_business INT,

    -- Branding
    logo_url VARCHAR(500),
    brand_color_primary VARCHAR(7),
    brand_color_secondary VARCHAR(7),

    -- Owner Info
    owner_name VARCHAR(255),
    owner_email VARCHAR(255),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Deployments Table
CREATE TABLE deployments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    template_id UUID REFERENCES templates(id) NOT NULL,
    company_id UUID REFERENCES companies(id) NOT NULL,

    -- Deployment Details
    domain VARCHAR(255) NOT NULL UNIQUE,
    subdomain VARCHAR(255),
    status VARCHAR(50), -- 'pending', 'deploying', 'live', 'failed', 'archived'
    deployment_date TIMESTAMP,

    -- Customization
    customizations JSONB DEFAULT '{}', -- {colors, content, components_enabled, etc}
    custom_content JSONB DEFAULT '{}', -- {hero_headline, about_text, etc}

    -- Performance
    lighthouse_score INT,
    page_speed_score INT,
    last_performance_check TIMESTAMP,

    -- Analytics
    total_visits INT DEFAULT 0,
    total_leads INT DEFAULT 0,
    lead_conversion_rate DECIMAL(5,2),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deployed_by UUID REFERENCES users(id)
);

-- Template Customizations (per company)
CREATE TABLE template_customizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deployment_id UUID REFERENCES deployments(id) NOT NULL,

    -- Component-level customizations
    component_name VARCHAR(255), -- 'Hero', 'Services', 'Testimonials', etc
    custom_settings JSONB,
    custom_content JSONB,
    custom_styles JSONB, -- CSS overrides

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255),
    full_name VARCHAR(255),
    role VARCHAR(50), -- 'admin', 'template-developer', 'company-manager'
    is_active BOOLEAN DEFAULT true,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Analytics Events
CREATE TABLE analytics_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deployment_id UUID REFERENCES deployments(id),
    event_type VARCHAR(100), -- 'page_view', 'contact_form_submit', 'cta_click', etc
    event_data JSONB,
    user_ip VARCHAR(45),
    user_agent TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_templates_framework ON templates(framework);
CREATE INDEX idx_templates_status ON templates(status);
CREATE INDEX idx_companies_slug ON companies(slug);
CREATE INDEX idx_deployments_template_id ON deployments(template_id);
CREATE INDEX idx_deployments_company_id ON deployments(company_id);
CREATE INDEX idx_deployments_status ON deployments(status);
CREATE INDEX idx_customizations_deployment_id ON template_customizations(deployment_id);
CREATE INDEX idx_analytics_deployment_id ON analytics_events(deployment_id);
CREATE INDEX idx_analytics_event_type ON analytics_events(event_type);
