// lead-generator-api/server.ts
import express from 'express';
import { Pool } from 'pg';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

app.use(cors());
app.use(express.json());

// ============================================
// DATABASE SCHEMA
// ============================================

/*
CREATE TABLE lead_campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    target_locations TEXT[], -- Array of locations
    min_rating DECIMAL(2,1) DEFAULT 4.0,
    min_review_count INT DEFAULT 20,
    results_per_location INT DEFAULT 50,
    google_sheet_id VARCHAR(255),
    status VARCHAR(50) DEFAULT 'pending', -- pending, running, completed, failed
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE leads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id UUID REFERENCES lead_campaigns(id),
    company_name VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    email VARCHAR(255),
    address TEXT,
    rating DECIMAL(2,1),
    review_count INT,
    years_in_business VARCHAR(50),
    services_offered VARCHAR(255),
    specialties TEXT,
    service_area TEXT,
    unique_selling_points TEXT,
    google_maps_url TEXT,
    research_sources TEXT,
    location_searched VARCHAR(255),
    outreach_status VARCHAR(50) DEFAULT 'new', -- new, contacted, interested, not_interested
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_leads_campaign ON leads(campaign_id);
CREATE INDEX idx_leads_outreach_status ON leads(outreach_status);
CREATE INDEX idx_campaigns_status ON lead_campaigns(status);
*/

// ============================================
// CAMPAIGN ENDPOINTS
// ============================================

// Create new lead generation campaign
app.post('/api/campaigns', async (req, res) => {
  try {
    const {
      name,
      target_locations,
      min_rating,
      min_review_count,
      results_per_location,
      google_sheet_id,
    } = req.body;

    const result = await pool.query(
      `INSERT INTO lead_campaigns 
       (name, target_locations, min_rating, min_review_count, results_per_location, google_sheet_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [name, target_locations, min_rating, min_review_count, results_per_location, google_sheet_id]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get all campaigns
app.get('/api/campaigns', async (req, res) => {
  try {
    const { status } = req.query;
    let query = 'SELECT * FROM lead_campaigns';
    const params = [];

    if (status) {
      query += ' WHERE status = $1';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC';
    const result = await pool.query(query, params);

    res.json({ success: true, data: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Start campaign
app.post('/api/campaigns/:id/start', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `UPDATE lead_campaigns 
       SET status = 'running', started_at = CURRENT_TIMESTAMP
       WHERE id = $1
       RETURNING *`,
      [id]
    );

    // TODO: Trigger lead generation job (background worker)
    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// LEADS ENDPOINTS
// ============================================

// Get leads by campaign
app.get('/api/campaigns/:campaign_id/leads', async (req, res) => {
  try {
    const { campaign_id } = req.params;
    const { outreach_status } = req.query;

    let query = 'SELECT * FROM leads WHERE campaign_id = $1';
    const params = [campaign_id];

    if (outreach_status) {
      query += ' AND outreach_status = $2';
      params.push(outreach_status);
    }

    query += ' ORDER BY rating DESC, review_count DESC';
    const result = await pool.query(query, params);

    res.json({ success: true, data: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update lead outreach status
app.patch('/api/leads/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { outreach_status, notes } = req.body;

    const result = await pool.query(
      `UPDATE leads 
       SET outreach_status = $1, notes = $2, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3
       RETURNING *`,
      [outreach_status, notes, id]
    );

    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get campaign statistics
app.get('/api/campaigns/:id/stats', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `SELECT 
        COUNT(*) as total_leads,
        COUNT(*) FILTER (WHERE outreach_status = 'contacted') as contacted,
        COUNT(*) FILTER (WHERE outreach_status = 'interested') as interested,
        COUNT(*) FILTER (WHERE email != 'Not found') as has_email,
        AVG(rating) as avg_rating,
        AVG(review_count) as avg_reviews
       FROM leads
       WHERE campaign_id = $1`,
      [id]
    );

    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Lead Generator API running on port ${PORT}`);
});
