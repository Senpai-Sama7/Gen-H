
"""
HVAC LEAD GENERATOR - Complete Automated System

FEATURES:
1. Searches Google Maps & Yelp for HVAC companies with 4+ star reviews
2. Verifies they have no website
3. Extracts contact information (phone, email, address)
4. Researches company (services, years in business, service areas)
5. Exports to Google Sheets for outreach

WORKFLOW:
1. Search Google Maps for HVAC companies by location
2. Filter for high ratings (4.0+) and review counts
3. Cross-reference with Yelp for additional data
4. Check if they have a website (if yes, skip)
5. Extract contact info and business details
6. Research company online
7. Export to Google Sheets with all data
"""

import os
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configuration
TARGET_LOCATIONS = os.environ.get("target_locations", "Chicago, IL").split(";")
MIN_RATING = float(os.environ.get("min_rating", "4.0"))
MIN_REVIEW_COUNT = int(os.environ.get("min_review_count", "20"))
GOOGLE_SHEET_URL = os.environ.get("google_sheet_url")
RESULTS_PER_LOCATION = int(os.environ.get("results_per_location", "50"))

print(f"[{datetime.now().isoformat()}] Starting HVAC Lead Generator")
print(f"  Target locations: {len(TARGET_LOCATIONS)}")
print(f"  Min rating: {MIN_RATING}")
print(f"  Min reviews: {MIN_REVIEW_COUNT}")
print(f"  Results per location: {RESULTS_PER_LOCATION}")

# Extract spreadsheet ID
import re
if "docs.google.com" in GOOGLE_SHEET_URL:
    match = re.search(r'/d/([a-zA-Z0-9-_]+)', GOOGLE_SHEET_URL)
    spreadsheet_id = match.group(1) if match else GOOGLE_SHEET_URL
else:
    spreadsheet_id = GOOGLE_SHEET_URL

# Step 1: Search for HVAC companies
print(f"\n[{datetime.now().isoformat()}] STEP 1: Searching for HVAC companies")

all_leads = []

for location in TARGET_LOCATIONS:
    print(f"\n  Searching in: {location}")

    # Search Google Maps
    gmaps_result, gmaps_error = run_composio_tool(
        "GOOGLE_MAPS_TEXT_SEARCH",
        {
            "textQuery": f"HVAC companies in {location}",
            "maxResultCount": 20,
            "fieldMask": "places.id,places.displayName,places.formattedAddress,places.nationalPhoneNumber,places.websiteUri,places.rating,places.userRatingCount,places.types,places.googleMapsUri"
        }
    )

    if gmaps_error:
        print(f"    ⚠️ Google Maps error: {gmaps_error}")
        continue

    # Parse Google Maps results
    gmaps_data = gmaps_result.get("data", {})
    places = gmaps_data.get("places", [])
    print(f"    Found {len(places)} places on Google Maps")

    for place in places:
        rating = place.get("rating", 0)
        review_count = place.get("userRatingCount", 0)
        website = place.get("websiteUri", "")

        # Filter criteria
        if rating >= MIN_RATING and review_count >= MIN_REVIEW_COUNT and not website:
            lead = {
                "name": place.get("displayName", {}).get("text", ""),
                "address": place.get("formattedAddress", ""),
                "phone": place.get("nationalPhoneNumber", ""),
                "rating": rating,
                "review_count": review_count,
                "website": "None",
                "google_maps_url": place.get("googleMapsUri", ""),
                "place_id": place.get("id", ""),
                "source": "Google Maps",
                "location": location,
                "researched": False
            }
            all_leads.append(lead)
            print(f"      ✅ {lead['name']} - {rating}★ ({review_count} reviews) - NO WEBSITE")

print(f"\n[{datetime.now().isoformat()}] Total leads found (no website): {len(all_leads)}")

# Step 2: Research each company
print(f"\n[{datetime.now().isoformat()}] STEP 2: Researching companies")

def research_company(lead):
    """Research a single company for more details"""
    company_name = lead["name"]
    location = lead["location"]

    print(f"  🔍 Researching: {company_name}")

    try:
        # Search web for company info
        search_result, search_error = run_composio_tool(
            "COMPOSIO_SEARCH_WEB",
            {"query": f"{company_name} {location} HVAC reviews services"}
        )

        if not search_error and search_result:
            data = search_result.get("data", {}).get("results", {})
            answer = data.get("answer", "")
            citations = data.get("citations", [])

            # Extract insights using LLM
            prompt = f"""
Analyze the following information about {company_name} and extract:
1. Years in business (if mentioned)
2. Services offered (residential, commercial, both)
3. Specialties (installation, repair, maintenance, emergency)
4. Service area/radius
5. Any unique selling points
6. Email address (if found in text)

Information:
{answer[:2000]}

Return JSON:
{{
  "years_in_business": "X years" or "Unknown",
  "services": "residential/commercial/both",
  "specialties": ["service1", "service2"],
  "service_area": "description",
  "unique_selling_points": "key differentiators",
  "email": "email@example.com" or "Not found"
}}
"""

            research, llm_error = invoke_llm(prompt, reasoning_effort="medium")

            if not llm_error:
                try:
                    research_data = json.loads(research)
                    lead.update({
                        "years_in_business": research_data.get("years_in_business", "Unknown"),
                        "services_offered": research_data.get("services", "Unknown"),
                        "specialties": ", ".join(research_data.get("specialties", [])),
                        "service_area": research_data.get("service_area", "Unknown"),
                        "unique_selling_points": research_data.get("unique_selling_points", ""),
                        "email": research_data.get("email", "Not found"),
                        "researched": True
                    })
                except:
                    pass

            # Add citation links
            if citations:
                lead["research_sources"] = "; ".join([c.get("url", "") for c in citations[:3]])

        return lead
    except Exception as e:
        print(f"    ⚠️ Research error for {company_name}: {str(e)}")
        lead["research_error"] = str(e)
        return lead

# Research in parallel (max 10 concurrent)
print("  Running parallel research...")
MAX_WORKERS = 10
researched_leads = []

with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    futures = [executor.submit(research_company, lead) for lead in all_leads[:RESULTS_PER_LOCATION]]

    for future in as_completed(futures):
        result = future.result()
        researched_leads.append(result)

print(f"\n[{datetime.now().isoformat()}] Researched {len(researched_leads)} companies")

# Step 3: Format for Google Sheets
print(f"\n[{datetime.now().isoformat()}] STEP 3: Formatting data for Google Sheets")

# Create header row
headers = [
    "Company Name",
    "Phone",
    "Email",
    "Address",
    "Rating",
    "Review Count",
    "Years in Business",
    "Services",
    "Specialties",
    "Service Area",
    "Unique Selling Points",
    "Google Maps URL",
    "Research Sources",
    "Location Searched",
    "Date Added"
]

# Format data rows
rows = [headers]
for lead in researched_leads:
    row = [
        lead.get("name", ""),
        lead.get("phone", ""),
        lead.get("email", "Not found"),
        lead.get("address", ""),
        str(lead.get("rating", "")),
        str(lead.get("review_count", "")),
        lead.get("years_in_business", "Unknown"),
        lead.get("services_offered", "Unknown"),
        lead.get("specialties", ""),
        lead.get("service_area", "Unknown"),
        lead.get("unique_selling_points", ""),
        lead.get("google_maps_url", ""),
        lead.get("research_sources", ""),
        lead.get("location", ""),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ]
    rows.append(row)

print(f"  Formatted {len(rows)-1} lead rows")

# Step 4: Write to Google Sheets
print(f"\n[{datetime.now().isoformat()}] STEP 4: Writing to Google Sheets")

# Check if sheet exists, create if not
sheets_result, sheets_error = run_composio_tool(
    "GOOGLESHEETS_GET_SHEET_NAMES",
    {"spreadsheet_id": spreadsheet_id}
)

if sheets_error:
    raise Exception(f"Failed to get sheet names: {sheets_error}")

sheet_names = sheets_result.get("data", {}).get("sheets", [])
print(f"  Existing sheets: {sheet_names}")

# Create new sheet for leads
sheet_name = f"HVAC_Leads_{datetime.now().strftime('%Y%m%d_%H%M')}"
create_result, create_error = run_composio_tool(
    "GOOGLESHEETS_ADD_SHEET",
    {
        "spreadsheetId": spreadsheet_id,
        "title": sheet_name,
        "properties": {
            "gridProperties": {
                "rowCount": len(rows) + 10,
                "columnCount": len(headers),
                "frozenRowCount": 1  # Freeze header row
            }
        }
    }
)

if create_error:
    print(f"  ⚠️ Failed to create new sheet: {create_error}")
    # Fall back to first sheet
    sheet_name = sheet_names[0] if sheet_names else "Sheet1"
    print(f"  Using existing sheet: {sheet_name}")

# Write data
write_result, write_error = run_composio_tool(
    "GOOGLESHEETS_BATCH_UPDATE",
    {
        "spreadsheet_id": spreadsheet_id,
        "sheet_name": sheet_name,
        "values": rows,
        "first_cell_location": "A1",
        "valueInputOption": "USER_ENTERED"
    }
)

if write_error:
    raise Exception(f"Failed to write to Google Sheets: {write_error}")

print(f"✅ Successfully wrote {len(rows)-1} leads to Google Sheets!")
print(f"  Sheet name: {sheet_name}")

# Summary output
output = {
    "total_leads_found": len(researched_leads),
    "sheet_name": sheet_name,
    "spreadsheet_id": spreadsheet_id,
    "spreadsheet_url": f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}/edit",
    "locations_searched": TARGET_LOCATIONS,
    "filter_criteria": {
        "min_rating": MIN_RATING,
        "min_reviews": MIN_REVIEW_COUNT,
        "has_website": "No"
    },
    "lead_breakdown": {
        "total": len(researched_leads),
        "researched": sum(1 for l in researched_leads if l.get("researched")),
        "with_email": sum(1 for l in researched_leads if l.get("email", "Not found") != "Not found")
    }
}

print(f"\n" + "="*80)
print("LEAD GENERATION COMPLETE")
print("="*80)
print(f"Total Leads: {output['total_leads_found']}")
print(f"Sheet URL: {output['spreadsheet_url']}")
print(f"\n✨ Ready for outreach!")

output
