// shared/components/Button.tsx
import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  ...props
}) => {
  const baseClasses = 'rounded-lg font-semibold transition duration-300';

  const variantClasses = {
    primary: 'bg-blue-600 hover:bg-blue-700 text-white',
    secondary: 'bg-slate-600 hover:bg-slate-700 text-white',
    outline: 'border-2 border-blue-600 text-blue-600 hover:bg-blue-50',
  };

  const sizeClasses = {
    sm: 'px-3 py-1 text-sm',
    md: 'px-6 py-2 text-base',
    lg: 'px-8 py-3 text-lg',
  };

  return (
    <button
      className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

// shared/components/ServiceCard.tsx
import React from 'react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
  image?: string;
  features?: string[];
}

export const ServiceCard: React.FC<ServiceCardProps> = ({
  title,
  description,
  icon,
  image,
  features,
}) => {
  return (
    <div className="bg-white rounded-lg shadow-lg hover:shadow-xl transition overflow-hidden group">
      {image && (
        <div className="overflow-hidden h-48">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
          />
        </div>
      )}
      <div className="p-6">
        {icon && <div className="text-4xl mb-4">{icon}</div>}
        <h3 className="text-xl font-bold text-slate-900 mb-2">{title}</h3>
        <p className="text-slate-600 mb-4">{description}</p>
        {features && (
          <ul className="space-y-2">
            {features.map((feature, i) => (
              <li key={i} className="flex items-center text-sm text-slate-700">
                <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                {feature}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

// shared/components/BeforeAfterSlider.tsx
import React, { useState } from 'react';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  beforeImage,
  afterImage,
  beforeLabel = 'Before',
  afterLabel = 'After',
}) => {
  const [sliderPosition, setSliderPosition] = useState(50);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const newPosition = ((e.clientX - rect.left) / rect.width) * 100;
    setSliderPosition(Math.max(0, Math.min(100, newPosition)));
  };

  return (
    <div
      className="relative w-full max-w-2xl mx-auto overflow-hidden rounded-lg"
      onMouseMove={handleMouseMove}
      style={{ cursor: 'col-resize' }}
    >
      <img src={beforeImage} alt={beforeLabel} className="w-full block" />

      <div
        className="absolute top-0 left-0 w-full h-full overflow-hidden"
        style={{ width: `${sliderPosition}%` }}
      >
        <img src={afterImage} alt={afterLabel} className="w-screen block" />
      </div>

      <div
        className="absolute top-0 left-0 w-1 h-full bg-white shadow-lg"
        style={{ left: `${sliderPosition}%` }}
      >
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-full p-2">
          <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
            <path d="M15 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" fill="none" />
            <path d="M9 19l7-7-7-7" stroke="currentColor" strokeWidth="2" fill="none" />
          </svg>
        </div>
      </div>

      <div className="absolute top-4 left-4 bg-black bg-opacity-50 text-white px-4 py-2 rounded">
        {beforeLabel}
      </div>
      <div className="absolute top-4 right-4 bg-black bg-opacity-50 text-white px-4 py-2 rounded">
        {afterLabel}
      </div>
    </div>
  );
};

// shared/components/InteractiveCalculator.tsx
import React, { useState } from 'react';

interface CalculatorProps {
  onCalculate?: (result: number) => void;
}

export const InteractiveCalculator: React.FC<CalculatorProps> = ({ onCalculate }) => {
  const [homeSize, setHomeSize] = useState(2000);
  const [climate, setClimate] = useState('moderate');
  const [currentSystem, setCurrentSystem] = useState('old');

  const calculateCost = () => {
    const baseCost = homeSize * 0.08;
    const climateMultiplier = climate === 'hot' ? 1.3 : climate === 'cold' ? 1.2 : 1;
    const systemMultiplier = currentSystem === 'none' ? 1.5 : 1;

    return Math.round(baseCost * climateMultiplier * systemMultiplier);
  };

  const estimatedCost = calculateCost();
  const estimatedSavings = Math.round((estimatedCost * 0.15) / 12);

  return (
    <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-8 max-w-lg mx-auto">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Energy Savings Calculator</h2>

      <div className="space-y-6">
        {/* Home Size Slider */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Home Size: {homeSize} sq ft
          </label>
          <input
            type="range"
            min="500"
            max="5000"
            step="100"
            value={homeSize}
            onChange={(e) => setHomeSize(parseInt(e.target.value))}
            className="w-full h-2 bg-blue-300 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Climate Zone */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Climate Zone</label>
          <select
            value={climate}
            onChange={(e) => setClimate(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
          >
            <option value="mild">Mild</option>
            <option value="moderate">Moderate</option>
            <option value="cold">Cold</option>
            <option value="hot">Hot</option>
          </select>
        </div>

        {/* Current System */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Current System</label>
          <select
            value={currentSystem}
            onChange={(e) => setCurrentSystem(e.target.value)}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900"
          >
            <option value="new">New (< 5 years)</option>
            <option value="old">Old (> 10 years)</option>
            <option value="none">No System</option>
          </select>
        </div>
      </div>

      {/* Results */}
      <div className="mt-8 pt-6 border-t-2 border-blue-300 space-y-4">
        <div className="bg-white rounded-lg p-4">
          <p className="text-slate-600 text-sm">Estimated System Cost</p>
          <p className="text-3xl font-bold text-blue-600">${estimatedCost.toLocaleString()}</p>
        </div>

        <div className="bg-white rounded-lg p-4">
          <p className="text-slate-600 text-sm">Monthly Savings</p>
          <p className="text-3xl font-bold text-green-600">${estimatedSavings}</p>
        </div>

        <button
          onClick={() => onCalculate?.(estimatedCost)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition"
        >
          Get Free Quote
        </button>
      </div>
    </div>
  );
};

// shared/components/Testimonials.tsx
import React, { useState } from 'react';

interface Testimonial {
  id: string;
  name: string;
  title: string;
  content: string;
  rating: number;
  image?: string;
  video?: string;
}

interface TestimonialsProps {
  testimonials: Testimonial[];
}

export const Testimonials: React.FC<TestimonialsProps> = ({ testimonials }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  if (!testimonials.length) return null;

  const current = testimonials[currentIndex];

  return (
    <div className="bg-slate-50 rounded-lg p-8 max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Customer Stories</h2>
        <div className="flex gap-2">
          <button
            onClick={prev}
            className="p-2 hover:bg-slate-200 rounded-full transition"
          >
            ←
          </button>
          <button
            onClick={next}
            className="p-2 hover:bg-slate-200 rounded-full transition"
          >
            →
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {current.image && (
          <img
            src={current.image}
            alt={current.name}
            className="w-16 h-16 rounded-full object-cover"
          />
        )}

        <div className="flex gap-1">
          {Array.from({ length: current.rating }).map((_, i) => (
            <span key={i} className="text-yellow-400">★</span>
          ))}
        </div>

        <p className="text-slate-700 italic leading-relaxed">"{current.content}"</p>

        <div>
          <p className="font-semibold text-slate-900">{current.name}</p>
          <p className="text-sm text-slate-600">{current.title}</p>
        </div>
      </div>

      <div className="flex gap-2 mt-6">
        {testimonials.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`w-2 h-2 rounded-full transition ${
              i === currentIndex ? 'bg-blue-600 w-6' : 'bg-slate-300'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
