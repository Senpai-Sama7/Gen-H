// api-gateway/server.ts
import express, { Request, Response } from 'express';
import cors from 'cors';
import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

app.use(cors());
app.use(express.json());

// ============================================
// TEMPLATES ENDPOINTS
// ============================================

// Get all templates
app.get('/api/templates', async (req: Request, res: Response) => {
  try {
    const { framework, status } = req.query;
    let query = 'SELECT * FROM templates WHERE 1=1';
    const params = [];

    if (framework) {
      query += ' AND framework = $' + (params.length + 1);
      params.push(framework);
    }
    if (status) {
      query += ' AND status = $' + (params.length + 1);
      params.push(status);
    }

    query += ' ORDER BY created_at DESC';
    const result = await pool.query(query, params);
    res.json({ success: true, data: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get single template
app.get('/api/templates/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT * FROM templates WHERE id = $1 OR slug = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Template not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create new template
app.post('/api/templates', async (req: Request, res: Response) => {
  try {
    const {
      name,
      slug,
      description,
      framework,
      primary_color,
      secondary_color,
      accent_color,
      typography_headline,
      typography_body,
      has_3d_viewer,
      has_calculator,
      has_before_after,
      has_testimonials,
      frontend_repo_url,
      backend_repo_url,
      created_by,
    } = req.body;

    const result = await pool.query(
      `INSERT INTO templates 
       (name, slug, description, framework, primary_color, secondary_color, 
        accent_color, typography_headline, typography_body, has_3d_viewer, 
        has_calculator, has_before_after, has_testimonials, frontend_repo_url, 
        backend_repo_url, created_by, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, 'active')
       RETURNING *`,
      [
        name, slug, description, framework, primary_color, secondary_color,
        accent_color, typography_headline, typography_body, has_3d_viewer,
        has_calculator, has_before_after, has_testimonials, frontend_repo_url,
        backend_repo_url, created_by,
      ]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// COMPANIES ENDPOINTS
// ============================================

app.get('/api/companies', async (req: Request, res: Response) => {
  try {
    const result = await pool.query('SELECT * FROM companies ORDER BY created_at DESC');
    res.json({ success: true, data: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/companies', async (req: Request, res: Response) => {
  try {
    const { name, slug, email, phone, owner_name, owner_email, business_type } = req.body;

    const result = await pool.query(
      `INSERT INTO companies (name, slug, email, phone, owner_name, owner_email, business_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [name, slug, email, phone, owner_name, owner_email, business_type]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// DEPLOYMENTS ENDPOINTS
// ============================================

app.get('/api/deployments', async (req: Request, res: Response) => {
  try {
    const { company_id, template_id, status } = req.query;
    let query = 'SELECT * FROM deployments WHERE 1=1';
    const params = [];

    if (company_id) {
      query += ' AND company_id = $' + (params.length + 1);
      params.push(company_id);
    }
    if (template_id) {
      query += ' AND template_id = $' + (params.length + 1);
      params.push(template_id);
    }
    if (status) {
      query += ' AND status = $' + (params.length + 1);
      params.push(status);
    }

    query += ' ORDER BY created_at DESC';
    const result = await pool.query(query, params);
    res.json({ success: true, data: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create deployment
app.post('/api/deployments', async (req: Request, res: Response) => {
  try {
    const { template_id, company_id, domain, customizations, deployed_by } = req.body;

    const result = await pool.query(
      `INSERT INTO deployments 
       (template_id, company_id, domain, customizations, deployed_by, status)
       VALUES ($1, $2, $3, $4, $5, 'pending')
       RETURNING *`,
      [template_id, company_id, domain, JSON.stringify(customizations), deployed_by]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update deployment customizations
app.patch('/api/deployments/:id/customize', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { customizations, custom_content } = req.body;

    const result = await pool.query(
      `UPDATE deployments 
       SET customizations = $1, custom_content = $2, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3
       RETURNING *`,
      [JSON.stringify(customizations), JSON.stringify(custom_content), id]
    );

    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Deploy to production
app.post('/api/deployments/:id/deploy', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Trigger deployment pipeline
    const result = await pool.query(
      `UPDATE deployments 
       SET status = 'deploying', deployment_date = CURRENT_TIMESTAMP
       WHERE id = $1
       RETURNING *`,
      [id]
    );

    // TODO: Trigger GitHub Actions or deployment service
    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================
// ANALYTICS ENDPOINTS
// ============================================

app.post('/api/analytics/:deployment_id', async (req: Request, res: Response) => {
  try {
    const { deployment_id } = req.params;
    const { event_type, event_data } = req.body;

    await pool.query(
      `INSERT INTO analytics_events (deployment_id, event_type, event_data)
       VALUES ($1, $2, $3)`,
      [deployment_id, event_type, JSON.stringify(event_data)]
    );

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/deployments/:id/analytics', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `SELECT 
        event_type,
        COUNT(*) as count,
        COUNT(DISTINCT user_ip) as unique_users
       FROM analytics_events
       WHERE deployment_id = $1
       GROUP BY event_type`,
      [id]
    );

    res.json({ success: true, data: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`API Gateway running on port ${PORT}`);
});
