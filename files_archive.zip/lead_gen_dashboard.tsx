// lead-dashboard/pages/index.tsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Link from 'next/link';

interface Campaign {
  id: string;
  name: string;
  target_locations: string[];
  min_rating: number;
  min_review_count: number;
  status: 'pending' | 'running' | 'completed' | 'failed';
  created_at: string;
}

interface Lead {
  id: string;
  company_name: string;
  phone: string;
  email: string;
  address: string;
  rating: number;
  review_count: number;
  outreach_status: 'new' | 'contacted' | 'interested' | 'not_interested';
}

export default function LeadGeneratorDashboard() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const fetchCampaigns = async () => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_API_URL}/campaigns`);
      setCampaigns(response.data.data || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      setLoading(false);
    }
  };

  const fetchLeads = async (campaignId: string) => {
    try {
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/campaigns/${campaignId}/leads`
      );
      setLeads(response.data.data || []);
    } catch (error) {
      console.error('Error fetching leads:', error);
    }
  };

  const startCampaign = async (campaignId: string) => {
    try {
      await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/campaigns/${campaignId}/start`);
      fetchCampaigns();
    } catch (error) {
      console.error('Error starting campaign:', error);
    }
  };

  const updateLeadStatus = async (leadId: string, status: string) => {
    try {
      await axios.patch(`${process.env.NEXT_PUBLIC_API_URL}/leads/${leadId}`, {
        outreach_status: status,
      });
      if (selectedCampaign) {
        fetchLeads(selectedCampaign.id);
      }
    } catch (error) {
      console.error('Error updating lead:', error);
    }
  };

  if (loading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            🎯 HVAC Lead Generator
          </h1>
          <p className="text-slate-600">
            Find HVAC companies with great reviews but no website
          </p>
        </div>

        {/* Create Campaign Button */}
        <div className="mb-8">
          <Link href="/campaigns/create">
            <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow">
              + New Campaign
            </button>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Campaigns List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-4">
                Campaigns ({campaigns.length})
              </h2>

              <div className="space-y-2">
                {campaigns.map((campaign) => (
                  <div
                    key={campaign.id}
                    onClick={() => {
                      setSelectedCampaign(campaign);
                      fetchLeads(campaign.id);
                    }}
                    className={`p-4 rounded-lg cursor-pointer transition ${
                      selectedCampaign?.id === campaign.id
                        ? 'bg-blue-100 border-2 border-blue-600'
                        : 'bg-slate-50 hover:bg-slate-100'
                    }`}
                  >
                    <h3 className="font-semibold text-slate-900">{campaign.name}</h3>
                    <p className="text-sm text-slate-600">
                      {campaign.target_locations.length} locations
                    </p>
                    <span
                      className={`inline-block mt-2 px-2 py-1 rounded text-xs font-semibold ${
                        campaign.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : campaign.status === 'running'
                          ? 'bg-blue-100 text-blue-800'
                          : campaign.status === 'failed'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {campaign.status}
                    </span>

                    {campaign.status === 'pending' && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          startCampaign(campaign.id);
                        }}
                        className="mt-2 px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                      >
                        Start
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Leads Table */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow p-6">
              {selectedCampaign ? (
                <>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-slate-900">
                      Leads: {selectedCampaign.name}
                    </h2>
                    <span className="text-slate-600">{leads.length} total</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-slate-100">
                        <tr>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Company</th>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Phone</th>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Rating</th>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Reviews</th>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Status</th>
                          <th className="px-4 py-2 text-left text-sm font-semibold">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {leads.map((lead) => (
                          <tr key={lead.id} className="border-t hover:bg-slate-50">
                            <td className="px-4 py-3">
                              <div>
                                <p className="font-semibold text-slate-900">
                                  {lead.company_name}
                                </p>
                                <p className="text-xs text-slate-500">{lead.address}</p>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm font-mono">{lead.phone}</td>
                            <td className="px-4 py-3">
                              <span className="text-yellow-500">★</span> {lead.rating}
                            </td>
                            <td className="px-4 py-3 text-sm">{lead.review_count}</td>
                            <td className="px-4 py-3">
                              <select
                                value={lead.outreach_status}
                                onChange={(e) => updateLeadStatus(lead.id, e.target.value)}
                                className="px-2 py-1 rounded border text-sm"
                              >
                                <option value="new">New</option>
                                <option value="contacted">Contacted</option>
                                <option value="interested">Interested</option>
                                <option value="not_interested">Not Interested</option>
                              </select>
                            </td>
                            <td className="px-4 py-3">
                              <a
                                href={lead.google_maps_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:text-blue-800 text-sm"
                              >
                                View
                              </a>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  Select a campaign to view leads
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
